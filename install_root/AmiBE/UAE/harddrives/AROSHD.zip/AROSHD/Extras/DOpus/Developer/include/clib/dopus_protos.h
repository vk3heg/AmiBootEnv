#ifndef CLIB_DOPUS_PROTOS_H
#define CLIB_DOPUS_PROTOS_H

/*
    *** Automatically generated from '/home/vsts/work/1/s/contrib/dopus/Library/dopus.conf'. Edits will be lost. ***
    Copyright (C) 1995-2025, The AROS Development Team. All rights reserved.
*/

#include <aros/libcall.h>

struct DOpusRemember;
struct ConfigStuff;
struct DOpusFileReq;
struct RequesterBase;
struct RequesterObject;
struct DOpusDateTime;
struct DOpusSimpleRequest;
struct StringData;
struct DOpusListView;
struct RMBGadget;
#include <dos/dos.h>
#include <intuition/intuition.h>

__BEGIN_DECLS


#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(int, FileRequest,
         AROS_LPA(struct DOpusFileReq*, freq, A0),
         LIBBASETYPEPTR, DOpusBase, 5, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP7(void, Do3DBox,
         AROS_LPA(struct RastPort*, rp, A0),
         AROS_LPA(int, x, D0),
         AROS_LPA(int, y, D1),
         AROS_LPA(int, w, D2),
         AROS_LPA(int, h, D3),
         AROS_LPA(int, tp, D4),
         AROS_LPA(int, bp, D5),
         LIBBASETYPEPTR, DOpusBase, 6, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP7(void, Do3DStringBox,
         AROS_LPA(struct RastPort*, rp, A0),
         AROS_LPA(int, x, D0),
         AROS_LPA(int, y, D1),
         AROS_LPA(int, w, D2),
         AROS_LPA(int, h, D3),
         AROS_LPA(int, tp, D4),
         AROS_LPA(int, bp, D5),
         LIBBASETYPEPTR, DOpusBase, 7, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP7(void, Do3DCycleBox,
         AROS_LPA(struct RastPort*, rp, A0),
         AROS_LPA(int, x, D0),
         AROS_LPA(int, y, D1),
         AROS_LPA(int, w, D2),
         AROS_LPA(int, h, D3),
         AROS_LPA(int, tp, D4),
         AROS_LPA(int, bp, D5),
         LIBBASETYPEPTR, DOpusBase, 8, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP8(void, DoArrow,
         AROS_LPA(struct RastPort*, p, A0),
         AROS_LPA(int, x, D0),
         AROS_LPA(int, y, D1),
         AROS_LPA(int, w, D2),
         AROS_LPA(int, h, D3),
         AROS_LPA(int, fg, D4),
         AROS_LPA(int, bg, D5),
         AROS_LPA(int, d, D6),
         LIBBASETYPEPTR, DOpusBase, 9, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(struct IORequest*, LCreateExtIO,
         AROS_LPA(struct MsgPort*, port, A0),
         AROS_LPA(int, size, D0),
         LIBBASETYPEPTR, DOpusBase, 11, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(struct MsgPort*, LCreatePort,
         AROS_LPA(char*, name, A0),
         AROS_LPA(int, pri, D0),
         LIBBASETYPEPTR, DOpusBase, 12, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, LDeleteExtIO,
         AROS_LPA(struct IORequest*, ioext, A0),
         LIBBASETYPEPTR, DOpusBase, 13, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, LDeletePort,
         AROS_LPA(struct MsgPort*, port, A0),
         LIBBASETYPEPTR, DOpusBase, 14, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(char, LToUpper,
         AROS_LPA(char, ch, D0),
         LIBBASETYPEPTR, DOpusBase, 15, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(char, LToLower,
         AROS_LPA(char, ch, D0),
         LIBBASETYPEPTR, DOpusBase, 16, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, LStrCat,
         AROS_LPA(char*, s1, A0),
         AROS_LPA(char*, s2, A1),
         LIBBASETYPEPTR, DOpusBase, 17, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(void, LStrnCat,
         AROS_LPA(char*, s1, A0),
         AROS_LPA(char*, s2, A1),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 18, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, LStrCpy,
         AROS_LPA(char*, to, A0),
         AROS_LPA(char*, from, A1),
         LIBBASETYPEPTR, DOpusBase, 19, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(void, LStrnCpy,
         AROS_LPA(char*, to, A0),
         AROS_LPA(char*, from, A1),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 20, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, LStrCmp,
         AROS_LPA(char*, s1, A0),
         AROS_LPA(char*, s2, A1),
         LIBBASETYPEPTR, DOpusBase, 21, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(int, LStrnCmp,
         AROS_LPA(char*, s1, A0),
         AROS_LPA(char*, s2, A1),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 22, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, LStrCmpI,
         AROS_LPA(char*, s1, A0),
         AROS_LPA(char*, s2, A1),
         LIBBASETYPEPTR, DOpusBase, 23, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(int, LStrnCmpI,
         AROS_LPA(char*, s1, A0),
         AROS_LPA(char*, s2, A1),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 24, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(int, StrCombine,
         AROS_LPA(char*, buf, A0),
         AROS_LPA(char*, one, A1),
         AROS_LPA(char*, two, A2),
         AROS_LPA(int, lim, D0),
         LIBBASETYPEPTR, DOpusBase, 25, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(int, StrConcat,
         AROS_LPA(char*, buf, A0),
         AROS_LPA(char*, cat, A1),
         AROS_LPA(int, lim, D0),
         LIBBASETYPEPTR, DOpusBase, 26, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, LParsePattern,
         AROS_LPA(char*, pat, A0),
         AROS_LPA(char*, parsepat, A1),
         LIBBASETYPEPTR, DOpusBase, 27, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, LMatchPattern,
         AROS_LPA(char*, parsepat, A0),
         AROS_LPA(char*, str, A1),
         LIBBASETYPEPTR, DOpusBase, 28, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, LParsePatternI,
         AROS_LPA(char*, parsepat, A0),
         AROS_LPA(char*, str, A1),
         LIBBASETYPEPTR, DOpusBase, 29, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, LMatchPatternI,
         AROS_LPA(char*, parsepat, A0),
         AROS_LPA(char*, str, A1),
         LIBBASETYPEPTR, DOpusBase, 30, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(void, BtoCStr,
         AROS_LPA(BSTR, bstr, A0),
         AROS_LPA(char*, cstr, A1),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 31, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, Assign,
         AROS_LPA(char*, name, A0),
         AROS_LPA(char*, dir, A1),
         LIBBASETYPEPTR, DOpusBase, 32, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(char*, BaseName,
         AROS_LPA(char*, path, A0),
         LIBBASETYPEPTR, DOpusBase, 33, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, CompareLock,
         AROS_LPA(BPTR, l1, A0),
         AROS_LPA(BPTR, l2, A1),
         LIBBASETYPEPTR, DOpusBase, 34, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(int, PathName,
         AROS_LPA(BPTR, lock, A0),
         AROS_LPA(char*, buf, A1),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 35, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(int, SendPacket,
         AROS_LPA(struct MsgPort*, port, A0),
         AROS_LPA(int, action, D0),
         AROS_LPA(IPTR*, args, A1),
         AROS_LPA(int, nargs, D1),
         LIBBASETYPEPTR, DOpusBase, 36, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(int, TackOn,
         AROS_LPA(char*, path, A0),
         AROS_LPA(char*, file, A1),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 37, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(int, StampToStr,
         AROS_LPA(struct DOpusDateTime*, dt, A0),
         LIBBASETYPEPTR, DOpusBase, 38, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(int, StrToStamp,
         AROS_LPA(struct DOpusDateTime*, dt, A0),
         LIBBASETYPEPTR, DOpusBase, 39, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, AddListView,
         AROS_LPA(struct DOpusListView*, view, A0),
         AROS_LPA(int, count, D0),
         LIBBASETYPEPTR, DOpusBase, 40, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(struct DOpusListView*, ListViewIDCMP,
         AROS_LPA(struct DOpusListView*, view, A0),
         AROS_LPA(struct IntuiMessage*, imsg, A1),
         LIBBASETYPEPTR, DOpusBase, 41, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, RefreshListView,
         AROS_LPA(struct DOpusListView*, view, A0),
         AROS_LPA(int, count, D0),
         LIBBASETYPEPTR, DOpusBase, 42, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, RemoveListView,
         AROS_LPA(struct DOpusListView*, view, A0),
         AROS_LPA(int, count, D0),
         LIBBASETYPEPTR, DOpusBase, 43, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(void, DrawCheckMark,
         AROS_LPA(struct RastPort*, rp, A0),
         AROS_LPA(int, x, D0),
         AROS_LPA(int, y, D1),
         AROS_LPA(int, checked, D2),
         LIBBASETYPEPTR, DOpusBase, 44, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP5(void, FixSliderBody,
         AROS_LPA(struct Window*, win, A0),
         AROS_LPA(struct Gadget*, gad, A1),
         AROS_LPA(int, count, D0),
         AROS_LPA(int, lines, D1),
         AROS_LPA(int, show, D2),
         LIBBASETYPEPTR, DOpusBase, 45, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP6(void, FixSliderPot,
         AROS_LPA(struct Window*, win, A0),
         AROS_LPA(struct Gadget*, gad, A1),
         AROS_LPA(int, off, D0),
         AROS_LPA(int, count, D1),
         AROS_LPA(int, lines, D2),
         AROS_LPA(int, show, D3),
         LIBBASETYPEPTR, DOpusBase, 46, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(int, GetSliderPos,
         AROS_LPA(struct Gadget*, gad, A0),
         AROS_LPA(int, count, D0),
         AROS_LPA(int, lines, D1),
         LIBBASETYPEPTR, DOpusBase, 47, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(void*, LAllocRemember,
         AROS_LPA(struct DOpusRemember**, key, A0),
         AROS_LPA(ULONG, size, D0),
         AROS_LPA(ULONG, type, D1),
         LIBBASETYPEPTR, DOpusBase, 48, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, LFreeRemember,
         AROS_LPA(struct DOpusRemember**, key, A0),
         LIBBASETYPEPTR, DOpusBase, 49, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, SetBusyPointer,
         AROS_LPA(struct Window*, wind, A0),
         LIBBASETYPEPTR, DOpusBase, 50, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, GetWBScreen,
         AROS_LPA(struct Screen*, scrbuf, A0),
         LIBBASETYPEPTR, DOpusBase, 51, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(int, SearchPathList,
         AROS_LPA(char*, name, A0),
         AROS_LPA(char*, buf, A1),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 52, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, CheckExist,
         AROS_LPA(char*, name, A0),
         AROS_LPA(int*, size, A1),
         LIBBASETYPEPTR, DOpusBase, 53, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, CompareDate,
         AROS_LPA(struct DateStamp*, date, A0),
         AROS_LPA(struct DateStamp*, date2, A1),
         LIBBASETYPEPTR, DOpusBase, 54, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, Seed,
         AROS_LPA(int, seed, D0),
         LIBBASETYPEPTR, DOpusBase, 55, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(int, Random,
         AROS_LPA(int, limit, D0),
         LIBBASETYPEPTR, DOpusBase, 56, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, StrToUpper,
         AROS_LPA(char*, from, A0),
         AROS_LPA(char*, to, A1),
         LIBBASETYPEPTR, DOpusBase, 57, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, StrToLower,
         AROS_LPA(char*, from, A0),
         AROS_LPA(char*, to, A1),
         LIBBASETYPEPTR, DOpusBase, 58, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP5(int, RawkeyToStr,
         AROS_LPA(UWORD, code, D0),
         AROS_LPA(UWORD, qual, D1),
         AROS_LPA(char*, buf, A0),
         AROS_LPA(char*, kbuf, A1),
         AROS_LPA(int, len, D2),
         LIBBASETYPEPTR, DOpusBase, 59, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, DoRMBGadget,
         AROS_LPA(struct RMBGadget*, gad, A0),
         AROS_LPA(struct Window*, window, A1),
         LIBBASETYPEPTR, DOpusBase, 60, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP7(int, AddGadgets,
         AROS_LPA(struct Window*, win, A0),
         AROS_LPA(struct Gadget*, firstgad, A1),
         AROS_LPA(char**, text, A2),
         AROS_LPA(int, count, D0),
         AROS_LPA(int, fg, D1),
         AROS_LPA(int, bg, D2),
         AROS_LPA(int, add, D3),
         LIBBASETYPEPTR, DOpusBase, 61, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, ActivateStrGad,
         AROS_LPA(struct Gadget*, gadget, A0),
         AROS_LPA(struct Window*, window, A1),
         LIBBASETYPEPTR, DOpusBase, 62, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, RefreshStrGad,
         AROS_LPA(struct Gadget*, gadget, A0),
         AROS_LPA(struct Window*, window, A1),
         LIBBASETYPEPTR, DOpusBase, 63, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(int, CheckNumGad,
         AROS_LPA(struct Gadget*, gad, A0),
         AROS_LPA(struct Window*, win, A1),
         AROS_LPA(int, min, D0),
         AROS_LPA(int, max, D1),
         LIBBASETYPEPTR, DOpusBase, 64, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(int, CheckHexGad,
         AROS_LPA(struct Gadget*, gad, A0),
         AROS_LPA(struct Window*, win, A1),
         AROS_LPA(int, min, D0),
         AROS_LPA(int, max, D1),
         LIBBASETYPEPTR, DOpusBase, 65, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, Atoh,
         AROS_LPA(char*, buf, A0),
         AROS_LPA(int, len, D0),
         LIBBASETYPEPTR, DOpusBase, 66, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, HiliteGad,
         AROS_LPA(struct Gadget*, gad, A0),
         AROS_LPA(struct RastPort*, rp, A1),
         LIBBASETYPEPTR, DOpusBase, 67, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, DoSimpleRequest,
         AROS_LPA(struct Window*, window, A0),
         AROS_LPA(struct DOpusSimpleRequest*, simple, A1),
         LIBBASETYPEPTR, DOpusBase, 68, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, ReadConfig,
         AROS_LPA(char*, name, A0),
         AROS_LPA(struct ConfigStuff*, cstuff, A1),
         LIBBASETYPEPTR, DOpusBase, 69, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, SaveConfig,
         AROS_LPA(char*, name, A0),
         AROS_LPA(struct ConfigStuff*, cstuff, A1),
         LIBBASETYPEPTR, DOpusBase, 70, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(int, DefaultConfig,
         AROS_LPA(struct ConfigStuff*, cstuff, A0),
         LIBBASETYPEPTR, DOpusBase, 71, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(int, GetDevices,
         AROS_LPA(struct ConfigStuff*, cstuff, A0),
         LIBBASETYPEPTR, DOpusBase, 72, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP5(void, AssignGadget,
         AROS_LPA(struct ConfigStuff*, cstuff, A0),
         AROS_LPA(int, bk, D0),
         AROS_LPA(int, gad, D1),
         AROS_LPA(const char*, name, A1),
         AROS_LPA(const char*, func, A2),
         LIBBASETYPEPTR, DOpusBase, 73, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(void, AssignMenu,
         AROS_LPA(struct ConfigStuff*, cstuff, A0),
         AROS_LPA(int, men, D0),
         AROS_LPA(const char*, name, A1),
         AROS_LPA(const char*, func, A2),
         LIBBASETYPEPTR, DOpusBase, 74, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(int, FindSystemFile,
         AROS_LPA(char*, name, A0),
         AROS_LPA(char*, buf, A1),
         AROS_LPA(int, size, D0),
         AROS_LPA(int, type, D1),
         LIBBASETYPEPTR, DOpusBase, 75, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP8(void, Do3DFrame,
         AROS_LPA(struct RastPort*, rp, A0),
         AROS_LPA(int, x, D0),
         AROS_LPA(int, y, D1),
         AROS_LPA(int, w, D2),
         AROS_LPA(int, h, D3),
         AROS_LPA(char*, title, A1),
         AROS_LPA(int, hi, D4),
         AROS_LPA(int, lo, D5),
         LIBBASETYPEPTR, DOpusBase, 76, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, FreeConfig,
         AROS_LPA(struct ConfigStuff*, cstuff, A0),
         LIBBASETYPEPTR, DOpusBase, 77, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(void, DoCycleGadget,
         AROS_LPA(struct Gadget*, gad, A0),
         AROS_LPA(struct Window*, window, A1),
         AROS_LPA(char**, choices, A2),
         AROS_LPA(int, select, D0),
         LIBBASETYPEPTR, DOpusBase, 78, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP5(void, UScoreText,
         AROS_LPA(struct RastPort*, rp, A0),
         AROS_LPA(char*, buf, A1),
         AROS_LPA(int, xp, D0),
         AROS_LPA(int, yp, D1),
         AROS_LPA(int, up, D2),
         LIBBASETYPEPTR, DOpusBase, 79, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(void, DisableGadget,
         AROS_LPA(struct Gadget*, gad, A0),
         AROS_LPA(struct RastPort*, rp, A1),
         AROS_LPA(int, xoff, D0),
         AROS_LPA(int, yoff, D1),
         LIBBASETYPEPTR, DOpusBase, 80, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(void, EnableGadget,
         AROS_LPA(struct Gadget*, gad, A0),
         AROS_LPA(struct RastPort*, rp, A1),
         AROS_LPA(int, xoff, D0),
         AROS_LPA(int, yoff, D1),
         LIBBASETYPEPTR, DOpusBase, 81, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(void, GhostGadget,
         AROS_LPA(struct Gadget*, gad, A0),
         AROS_LPA(struct RastPort*, rp, A1),
         AROS_LPA(int, xoff, D0),
         AROS_LPA(int, yoff, D1),
         LIBBASETYPEPTR, DOpusBase, 82, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP7(void, DrawRadioButton,
         AROS_LPA(struct RastPort*, rp, A0),
         AROS_LPA(int, x, D0),
         AROS_LPA(int, y, D1),
         AROS_LPA(int, w, D2),
         AROS_LPA(int, h, D3),
         AROS_LPA(int, hi, D4),
         AROS_LPA(int, lo, D5),
         LIBBASETYPEPTR, DOpusBase, 83, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP7(struct Image*, GetButtonImage,
         AROS_LPA(int, w, D0),
         AROS_LPA(int, h, D1),
         AROS_LPA(int, fg, D2),
         AROS_LPA(int, bg, D3),
         AROS_LPA(int, fpen, D4),
         AROS_LPA(int, bpen, D5),
         AROS_LPA(struct DOpusRemember**, key, A0),
         LIBBASETYPEPTR, DOpusBase, 84, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, ShowSlider,
         AROS_LPA(struct Window*, win, A0),
         AROS_LPA(struct Gadget*, gad, A1),
         LIBBASETYPEPTR, DOpusBase, 85, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(int, CheckConfig,
         AROS_LPA(struct ConfigStuff*, cstuff, A0),
         LIBBASETYPEPTR, DOpusBase, 86, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP4(struct Image*, GetCheckImage,
         AROS_LPA(int, fg, D0),
         AROS_LPA(int, bg, D1),
         AROS_LPA(int, pen, D2),
         AROS_LPA(struct DOpusRemember**, key, A0),
         LIBBASETYPEPTR, DOpusBase, 87, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(struct Window*, OpenRequester,
         AROS_LPA(struct RequesterBase*, reqbase, A0),
         LIBBASETYPEPTR, DOpusBase, 88, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, CloseRequester,
         AROS_LPA(struct RequesterBase*, reqbase, A0),
         LIBBASETYPEPTR, DOpusBase, 89, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(APTR, AddRequesterObject,
         AROS_LPA(struct RequesterBase*, reqbase, A0),
         AROS_LPA(struct TagItem*, taglist, A1),
         LIBBASETYPEPTR, DOpusBase, 90, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, RefreshRequesterObject,
         AROS_LPA(struct RequesterBase*, reqbase, A0),
         AROS_LPA(struct RequesterObject*, object, A1),
         LIBBASETYPEPTR, DOpusBase, 91, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP7(void, ObjectText,
         AROS_LPA(struct RequesterBase*, reqbase, A0),
         AROS_LPA(short, left, D0),
         AROS_LPA(short, top, D1),
         AROS_LPA(short, width, D2),
         AROS_LPA(short, height, D3),
         AROS_LPA(char*, text, A1),
         AROS_LPA(short, textpos, D4),
         LIBBASETYPEPTR, DOpusBase, 92, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP5(void, DoGlassImage,
         AROS_LPA(struct RastPort*, rp, A0),
         AROS_LPA(struct Gadget*, gadget, A1),
         AROS_LPA(int, shine, D0),
         AROS_LPA(int, shadow, D1),
         AROS_LPA(int, type, D2),
         LIBBASETYPEPTR, DOpusBase, 93, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP3(void, Decode_RLE,
         AROS_LPA(char*, source, A0),
         AROS_LPA(char*, dest, A1),
         AROS_LPA(int, size, D0),
         LIBBASETYPEPTR, DOpusBase, 94, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, ReadStringFile,
         AROS_LPA(struct StringData*, stringdata, A0),
         AROS_LPA(char*, filename, A1),
         LIBBASETYPEPTR, DOpusBase, 95, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP1(void, FreeStringFile,
         AROS_LPA(struct StringData*, stringdata, A0),
         LIBBASETYPEPTR, DOpusBase, 96, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, LFreeRemEntry,
         AROS_LPA(struct DOpusRemember**, key, A0),
         AROS_LPA(char*, pointer, A1),
         LIBBASETYPEPTR, DOpusBase, 97, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP5(void, AddGadgetBorders,
         AROS_LPA(struct DOpusRemember**, key, A0),
         AROS_LPA(struct Gadget*, gadget, A1),
         AROS_LPA(int, count, D0),
         AROS_LPA(int, shine, D1),
         AROS_LPA(int, shadow, D2),
         LIBBASETYPEPTR, DOpusBase, 98, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP8(void, CreateGadgetBorders,
         AROS_LPA(struct DOpusRemember**, key, A0),
         AROS_LPA(int, w, D0),
         AROS_LPA(int, h, D1),
         AROS_LPA(struct Border**, selborder, A1),
         AROS_LPA(struct Border**, unselborder, A2),
         AROS_LPA(int, dogear, D2),
         AROS_LPA(int, shine, D3),
         AROS_LPA(int, shadow, D4),
         LIBBASETYPEPTR, DOpusBase, 99, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(void, SelectGadget,
         AROS_LPA(struct Window*, window, A0),
         AROS_LPA(struct Gadget*, gadget, A1),
         LIBBASETYPEPTR, DOpusBase, 100, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)
AROS_LP2(int, FSSetMenuStrip,
         AROS_LPA(struct Window*, window, A0),
         AROS_LPA(struct Menu*, firstmenu, A1),
         LIBBASETYPEPTR, DOpusBase, 101, DOpus
);

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

__END_DECLS

#endif /* CLIB_DOPUS_PROTOS_H */
