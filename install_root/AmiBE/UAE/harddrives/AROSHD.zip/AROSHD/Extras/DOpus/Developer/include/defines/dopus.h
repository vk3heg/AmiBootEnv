#ifndef DEFINES_DOPUS_H
#define DEFINES_DOPUS_H

/*
    *** Automatically generated from '/home/vsts/work/1/s/contrib/dopus/Library/dopus.conf'. Edits will be lost. ***
    Copyright (C) 1995-2025, The AROS Development Team. All rights reserved.
*/

/*
    Desc: Defines for dopus
*/

#include <aros/libcall.h>
#include <exec/types.h>
#include <aros/symbolsets.h>
#include <aros/preprocessor/variadic/cast2iptr.hpp>

#if !defined(__DOPUS_LIBBASE)
#    define __DOPUS_LIBBASE DOpusBase
#endif

__BEGIN_DECLS


#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __FileRequest_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(int, FileRequest,\
         AROS_LCA(struct DOpusFileReq*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 5, DOpus);\
})

#define FileRequest(arg1) \
    __FileRequest_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Do3DBox_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC7NR(void, Do3DBox,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(int, (__arg4), D2), \
         AROS_LCA(int, (__arg5), D3), \
         AROS_LCA(int, (__arg6), D4), \
         AROS_LCA(int, (__arg7), D5), \
        struct DOpusBase *, (__DOpusBase), 6, DOpus);\
})

#define Do3DBox(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __Do3DBox_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Do3DStringBox_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC7NR(void, Do3DStringBox,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(int, (__arg4), D2), \
         AROS_LCA(int, (__arg5), D3), \
         AROS_LCA(int, (__arg6), D4), \
         AROS_LCA(int, (__arg7), D5), \
        struct DOpusBase *, (__DOpusBase), 7, DOpus);\
})

#define Do3DStringBox(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __Do3DStringBox_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Do3DCycleBox_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC7NR(void, Do3DCycleBox,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(int, (__arg4), D2), \
         AROS_LCA(int, (__arg5), D3), \
         AROS_LCA(int, (__arg6), D4), \
         AROS_LCA(int, (__arg7), D5), \
        struct DOpusBase *, (__DOpusBase), 8, DOpus);\
})

#define Do3DCycleBox(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __Do3DCycleBox_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DoArrow_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7, __arg8) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC8NR(void, DoArrow,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(int, (__arg4), D2), \
         AROS_LCA(int, (__arg5), D3), \
         AROS_LCA(int, (__arg6), D4), \
         AROS_LCA(int, (__arg7), D5), \
         AROS_LCA(int, (__arg8), D6), \
        struct DOpusBase *, (__DOpusBase), 9, DOpus);\
})

#define DoArrow(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) \
    __DoArrow_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), (arg8))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LCreateExtIO_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(struct IORequest*, LCreateExtIO,\
         AROS_LCA(struct MsgPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
        struct DOpusBase *, (__DOpusBase), 11, DOpus);\
})

#define LCreateExtIO(arg1, arg2) \
    __LCreateExtIO_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LCreatePort_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(struct MsgPort*, LCreatePort,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
        struct DOpusBase *, (__DOpusBase), 12, DOpus);\
})

#define LCreatePort(arg1, arg2) \
    __LCreatePort_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LDeleteExtIO_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, LDeleteExtIO,\
         AROS_LCA(struct IORequest*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 13, DOpus);\
})

#define LDeleteExtIO(arg1) \
    __LDeleteExtIO_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LDeletePort_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, LDeletePort,\
         AROS_LCA(struct MsgPort*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 14, DOpus);\
})

#define LDeletePort(arg1) \
    __LDeletePort_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LToUpper_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(char, LToUpper,\
         AROS_LCA(char, (__arg1), D0), \
        struct DOpusBase *, (__DOpusBase), 15, DOpus);\
})

#define LToUpper(arg1) \
    __LToUpper_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LToLower_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(char, LToLower,\
         AROS_LCA(char, (__arg1), D0), \
        struct DOpusBase *, (__DOpusBase), 16, DOpus);\
})

#define LToLower(arg1) \
    __LToLower_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LStrCat_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, LStrCat,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 17, DOpus);\
})

#define LStrCat(arg1, arg2) \
    __LStrCat_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LStrnCat_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3NR(void, LStrnCat,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 18, DOpus);\
})

#define LStrnCat(arg1, arg2, arg3) \
    __LStrnCat_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LStrCpy_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, LStrCpy,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 19, DOpus);\
})

#define LStrCpy(arg1, arg2) \
    __LStrCpy_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LStrnCpy_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3NR(void, LStrnCpy,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 20, DOpus);\
})

#define LStrnCpy(arg1, arg2, arg3) \
    __LStrnCpy_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LStrCmp_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, LStrCmp,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 21, DOpus);\
})

#define LStrCmp(arg1, arg2) \
    __LStrCmp_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LStrnCmp_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3(int, LStrnCmp,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 22, DOpus);\
})

#define LStrnCmp(arg1, arg2, arg3) \
    __LStrnCmp_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LStrCmpI_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, LStrCmpI,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 23, DOpus);\
})

#define LStrCmpI(arg1, arg2) \
    __LStrCmpI_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LStrnCmpI_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3(int, LStrnCmpI,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 24, DOpus);\
})

#define LStrnCmpI(arg1, arg2, arg3) \
    __LStrnCmpI_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __StrCombine_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4(int, StrCombine,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(char*, (__arg3), A2), \
         AROS_LCA(int, (__arg4), D0), \
        struct DOpusBase *, (__DOpusBase), 25, DOpus);\
})

#define StrCombine(arg1, arg2, arg3, arg4) \
    __StrCombine_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __StrConcat_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3(int, StrConcat,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 26, DOpus);\
})

#define StrConcat(arg1, arg2, arg3) \
    __StrConcat_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LParsePattern_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, LParsePattern,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 27, DOpus);\
})

#define LParsePattern(arg1, arg2) \
    __LParsePattern_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LMatchPattern_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, LMatchPattern,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 28, DOpus);\
})

#define LMatchPattern(arg1, arg2) \
    __LMatchPattern_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LParsePatternI_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, LParsePatternI,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 29, DOpus);\
})

#define LParsePatternI(arg1, arg2) \
    __LParsePatternI_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LMatchPatternI_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, LMatchPatternI,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 30, DOpus);\
})

#define LMatchPatternI(arg1, arg2) \
    __LMatchPatternI_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __BtoCStr_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3NR(void, BtoCStr,\
         AROS_LCA(BSTR, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 31, DOpus);\
})

#define BtoCStr(arg1, arg2, arg3) \
    __BtoCStr_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Assign_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, Assign,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 32, DOpus);\
})

#define Assign(arg1, arg2) \
    __Assign_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __BaseName_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(char*, BaseName,\
         AROS_LCA(char*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 33, DOpus);\
})

#define BaseName(arg1) \
    __BaseName_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __CompareLock_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, CompareLock,\
         AROS_LCA(BPTR, (__arg1), A0), \
         AROS_LCA(BPTR, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 34, DOpus);\
})

#define CompareLock(arg1, arg2) \
    __CompareLock_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __PathName_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3(int, PathName,\
         AROS_LCA(BPTR, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 35, DOpus);\
})

#define PathName(arg1, arg2, arg3) \
    __PathName_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __SendPacket_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4(int, SendPacket,\
         AROS_LCA(struct MsgPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(IPTR*, (__arg3), A1), \
         AROS_LCA(int, (__arg4), D1), \
        struct DOpusBase *, (__DOpusBase), 36, DOpus);\
})

#define SendPacket(arg1, arg2, arg3, arg4) \
    __SendPacket_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __TackOn_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3(int, TackOn,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 37, DOpus);\
})

#define TackOn(arg1, arg2, arg3) \
    __TackOn_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __StampToStr_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(int, StampToStr,\
         AROS_LCA(struct DOpusDateTime*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 38, DOpus);\
})

#define StampToStr(arg1) \
    __StampToStr_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __StrToStamp_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(int, StrToStamp,\
         AROS_LCA(struct DOpusDateTime*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 39, DOpus);\
})

#define StrToStamp(arg1) \
    __StrToStamp_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __AddListView_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, AddListView,\
         AROS_LCA(struct DOpusListView*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
        struct DOpusBase *, (__DOpusBase), 40, DOpus);\
})

#define AddListView(arg1, arg2) \
    __AddListView_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __ListViewIDCMP_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(struct DOpusListView*, ListViewIDCMP,\
         AROS_LCA(struct DOpusListView*, (__arg1), A0), \
         AROS_LCA(struct IntuiMessage*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 41, DOpus);\
})

#define ListViewIDCMP(arg1, arg2) \
    __ListViewIDCMP_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __RefreshListView_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, RefreshListView,\
         AROS_LCA(struct DOpusListView*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
        struct DOpusBase *, (__DOpusBase), 42, DOpus);\
})

#define RefreshListView(arg1, arg2) \
    __RefreshListView_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __RemoveListView_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, RemoveListView,\
         AROS_LCA(struct DOpusListView*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
        struct DOpusBase *, (__DOpusBase), 43, DOpus);\
})

#define RemoveListView(arg1, arg2) \
    __RemoveListView_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DrawCheckMark_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4NR(void, DrawCheckMark,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(int, (__arg4), D2), \
        struct DOpusBase *, (__DOpusBase), 44, DOpus);\
})

#define DrawCheckMark(arg1, arg2, arg3, arg4) \
    __DrawCheckMark_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __FixSliderBody_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC5NR(void, FixSliderBody,\
         AROS_LCA(struct Window*, (__arg1), A0), \
         AROS_LCA(struct Gadget*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
         AROS_LCA(int, (__arg5), D2), \
        struct DOpusBase *, (__DOpusBase), 45, DOpus);\
})

#define FixSliderBody(arg1, arg2, arg3, arg4, arg5) \
    __FixSliderBody_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __FixSliderPot_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC6NR(void, FixSliderPot,\
         AROS_LCA(struct Window*, (__arg1), A0), \
         AROS_LCA(struct Gadget*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
         AROS_LCA(int, (__arg5), D2), \
         AROS_LCA(int, (__arg6), D3), \
        struct DOpusBase *, (__DOpusBase), 46, DOpus);\
})

#define FixSliderPot(arg1, arg2, arg3, arg4, arg5, arg6) \
    __FixSliderPot_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __GetSliderPos_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3(int, GetSliderPos,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
        struct DOpusBase *, (__DOpusBase), 47, DOpus);\
})

#define GetSliderPos(arg1, arg2, arg3) \
    __GetSliderPos_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LAllocRemember_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3(void*, LAllocRemember,\
         AROS_LCA(struct DOpusRemember**, (__arg1), A0), \
         AROS_LCA(ULONG, (__arg2), D0), \
         AROS_LCA(ULONG, (__arg3), D1), \
        struct DOpusBase *, (__DOpusBase), 48, DOpus);\
})

#define LAllocRemember(arg1, arg2, arg3) \
    __LAllocRemember_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LFreeRemember_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, LFreeRemember,\
         AROS_LCA(struct DOpusRemember**, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 49, DOpus);\
})

#define LFreeRemember(arg1) \
    __LFreeRemember_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __SetBusyPointer_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, SetBusyPointer,\
         AROS_LCA(struct Window*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 50, DOpus);\
})

#define SetBusyPointer(arg1) \
    __SetBusyPointer_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __GetWBScreen_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, GetWBScreen,\
         AROS_LCA(struct Screen*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 51, DOpus);\
})

#define GetWBScreen(arg1) \
    __GetWBScreen_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __SearchPathList_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3(int, SearchPathList,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 52, DOpus);\
})

#define SearchPathList(arg1, arg2, arg3) \
    __SearchPathList_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __CheckExist_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, CheckExist,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(int*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 53, DOpus);\
})

#define CheckExist(arg1, arg2) \
    __CheckExist_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __CompareDate_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, CompareDate,\
         AROS_LCA(struct DateStamp*, (__arg1), A0), \
         AROS_LCA(struct DateStamp*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 54, DOpus);\
})

#define CompareDate(arg1, arg2) \
    __CompareDate_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Seed_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, Seed,\
         AROS_LCA(int, (__arg1), D0), \
        struct DOpusBase *, (__DOpusBase), 55, DOpus);\
})

#define Seed(arg1) \
    __Seed_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Random_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(int, Random,\
         AROS_LCA(int, (__arg1), D0), \
        struct DOpusBase *, (__DOpusBase), 56, DOpus);\
})

#define Random(arg1) \
    __Random_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __StrToUpper_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, StrToUpper,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 57, DOpus);\
})

#define StrToUpper(arg1, arg2) \
    __StrToUpper_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __StrToLower_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, StrToLower,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 58, DOpus);\
})

#define StrToLower(arg1, arg2) \
    __StrToLower_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __RawkeyToStr_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC5(int, RawkeyToStr,\
         AROS_LCA(UWORD, (__arg1), D0), \
         AROS_LCA(UWORD, (__arg2), D1), \
         AROS_LCA(char*, (__arg3), A0), \
         AROS_LCA(char*, (__arg4), A1), \
         AROS_LCA(int, (__arg5), D2), \
        struct DOpusBase *, (__DOpusBase), 59, DOpus);\
})

#define RawkeyToStr(arg1, arg2, arg3, arg4, arg5) \
    __RawkeyToStr_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DoRMBGadget_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, DoRMBGadget,\
         AROS_LCA(struct RMBGadget*, (__arg1), A0), \
         AROS_LCA(struct Window*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 60, DOpus);\
})

#define DoRMBGadget(arg1, arg2) \
    __DoRMBGadget_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __AddGadgets_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC7(int, AddGadgets,\
         AROS_LCA(struct Window*, (__arg1), A0), \
         AROS_LCA(struct Gadget*, (__arg2), A1), \
         AROS_LCA(char**, (__arg3), A2), \
         AROS_LCA(int, (__arg4), D0), \
         AROS_LCA(int, (__arg5), D1), \
         AROS_LCA(int, (__arg6), D2), \
         AROS_LCA(int, (__arg7), D3), \
        struct DOpusBase *, (__DOpusBase), 61, DOpus);\
})

#define AddGadgets(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __AddGadgets_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __ActivateStrGad_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, ActivateStrGad,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct Window*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 62, DOpus);\
})

#define ActivateStrGad(arg1, arg2) \
    __ActivateStrGad_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __RefreshStrGad_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, RefreshStrGad,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct Window*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 63, DOpus);\
})

#define RefreshStrGad(arg1, arg2) \
    __RefreshStrGad_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __CheckNumGad_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4(int, CheckNumGad,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct Window*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
        struct DOpusBase *, (__DOpusBase), 64, DOpus);\
})

#define CheckNumGad(arg1, arg2, arg3, arg4) \
    __CheckNumGad_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __CheckHexGad_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4(int, CheckHexGad,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct Window*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
        struct DOpusBase *, (__DOpusBase), 65, DOpus);\
})

#define CheckHexGad(arg1, arg2, arg3, arg4) \
    __CheckHexGad_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Atoh_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, Atoh,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
        struct DOpusBase *, (__DOpusBase), 66, DOpus);\
})

#define Atoh(arg1, arg2) \
    __Atoh_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __HiliteGad_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, HiliteGad,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct RastPort*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 67, DOpus);\
})

#define HiliteGad(arg1, arg2) \
    __HiliteGad_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DoSimpleRequest_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, DoSimpleRequest,\
         AROS_LCA(struct Window*, (__arg1), A0), \
         AROS_LCA(struct DOpusSimpleRequest*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 68, DOpus);\
})

#define DoSimpleRequest(arg1, arg2) \
    __DoSimpleRequest_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __ReadConfig_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, ReadConfig,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(struct ConfigStuff*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 69, DOpus);\
})

#define ReadConfig(arg1, arg2) \
    __ReadConfig_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __SaveConfig_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, SaveConfig,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(struct ConfigStuff*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 70, DOpus);\
})

#define SaveConfig(arg1, arg2) \
    __SaveConfig_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DefaultConfig_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(int, DefaultConfig,\
         AROS_LCA(struct ConfigStuff*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 71, DOpus);\
})

#define DefaultConfig(arg1) \
    __DefaultConfig_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __GetDevices_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(int, GetDevices,\
         AROS_LCA(struct ConfigStuff*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 72, DOpus);\
})

#define GetDevices(arg1) \
    __GetDevices_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __AssignGadget_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC5NR(void, AssignGadget,\
         AROS_LCA(struct ConfigStuff*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(const char*, (__arg4), A1), \
         AROS_LCA(const char*, (__arg5), A2), \
        struct DOpusBase *, (__DOpusBase), 73, DOpus);\
})

#define AssignGadget(arg1, arg2, arg3, arg4, arg5) \
    __AssignGadget_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __AssignMenu_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4NR(void, AssignMenu,\
         AROS_LCA(struct ConfigStuff*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(const char*, (__arg3), A1), \
         AROS_LCA(const char*, (__arg4), A2), \
        struct DOpusBase *, (__DOpusBase), 74, DOpus);\
})

#define AssignMenu(arg1, arg2, arg3, arg4) \
    __AssignMenu_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __FindSystemFile_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4(int, FindSystemFile,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
        struct DOpusBase *, (__DOpusBase), 75, DOpus);\
})

#define FindSystemFile(arg1, arg2, arg3, arg4) \
    __FindSystemFile_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Do3DFrame_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7, __arg8) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC8NR(void, Do3DFrame,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(int, (__arg4), D2), \
         AROS_LCA(int, (__arg5), D3), \
         AROS_LCA(char*, (__arg6), A1), \
         AROS_LCA(int, (__arg7), D4), \
         AROS_LCA(int, (__arg8), D5), \
        struct DOpusBase *, (__DOpusBase), 76, DOpus);\
})

#define Do3DFrame(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) \
    __Do3DFrame_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), (arg8))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __FreeConfig_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, FreeConfig,\
         AROS_LCA(struct ConfigStuff*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 77, DOpus);\
})

#define FreeConfig(arg1) \
    __FreeConfig_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DoCycleGadget_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4NR(void, DoCycleGadget,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct Window*, (__arg2), A1), \
         AROS_LCA(char**, (__arg3), A2), \
         AROS_LCA(int, (__arg4), D0), \
        struct DOpusBase *, (__DOpusBase), 78, DOpus);\
})

#define DoCycleGadget(arg1, arg2, arg3, arg4) \
    __DoCycleGadget_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __UScoreText_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC5NR(void, UScoreText,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
         AROS_LCA(int, (__arg5), D2), \
        struct DOpusBase *, (__DOpusBase), 79, DOpus);\
})

#define UScoreText(arg1, arg2, arg3, arg4, arg5) \
    __UScoreText_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DisableGadget_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4NR(void, DisableGadget,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct RastPort*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
        struct DOpusBase *, (__DOpusBase), 80, DOpus);\
})

#define DisableGadget(arg1, arg2, arg3, arg4) \
    __DisableGadget_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __EnableGadget_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4NR(void, EnableGadget,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct RastPort*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
        struct DOpusBase *, (__DOpusBase), 81, DOpus);\
})

#define EnableGadget(arg1, arg2, arg3, arg4) \
    __EnableGadget_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __GhostGadget_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4NR(void, GhostGadget,\
         AROS_LCA(struct Gadget*, (__arg1), A0), \
         AROS_LCA(struct RastPort*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
        struct DOpusBase *, (__DOpusBase), 82, DOpus);\
})

#define GhostGadget(arg1, arg2, arg3, arg4) \
    __GhostGadget_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DrawRadioButton_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC7NR(void, DrawRadioButton,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(int, (__arg4), D2), \
         AROS_LCA(int, (__arg5), D3), \
         AROS_LCA(int, (__arg6), D4), \
         AROS_LCA(int, (__arg7), D5), \
        struct DOpusBase *, (__DOpusBase), 83, DOpus);\
})

#define DrawRadioButton(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __DrawRadioButton_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __GetButtonImage_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC7(struct Image*, GetButtonImage,\
         AROS_LCA(int, (__arg1), D0), \
         AROS_LCA(int, (__arg2), D1), \
         AROS_LCA(int, (__arg3), D2), \
         AROS_LCA(int, (__arg4), D3), \
         AROS_LCA(int, (__arg5), D4), \
         AROS_LCA(int, (__arg6), D5), \
         AROS_LCA(struct DOpusRemember**, (__arg7), A0), \
        struct DOpusBase *, (__DOpusBase), 84, DOpus);\
})

#define GetButtonImage(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __GetButtonImage_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __ShowSlider_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, ShowSlider,\
         AROS_LCA(struct Window*, (__arg1), A0), \
         AROS_LCA(struct Gadget*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 85, DOpus);\
})

#define ShowSlider(arg1, arg2) \
    __ShowSlider_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __CheckConfig_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(int, CheckConfig,\
         AROS_LCA(struct ConfigStuff*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 86, DOpus);\
})

#define CheckConfig(arg1) \
    __CheckConfig_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __GetCheckImage_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC4(struct Image*, GetCheckImage,\
         AROS_LCA(int, (__arg1), D0), \
         AROS_LCA(int, (__arg2), D1), \
         AROS_LCA(int, (__arg3), D2), \
         AROS_LCA(struct DOpusRemember**, (__arg4), A0), \
        struct DOpusBase *, (__DOpusBase), 87, DOpus);\
})

#define GetCheckImage(arg1, arg2, arg3, arg4) \
    __GetCheckImage_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __OpenRequester_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1(struct Window*, OpenRequester,\
         AROS_LCA(struct RequesterBase*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 88, DOpus);\
})

#define OpenRequester(arg1) \
    __OpenRequester_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __CloseRequester_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, CloseRequester,\
         AROS_LCA(struct RequesterBase*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 89, DOpus);\
})

#define CloseRequester(arg1) \
    __CloseRequester_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __AddRequesterObject_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(APTR, AddRequesterObject,\
         AROS_LCA(struct RequesterBase*, (__arg1), A0), \
         AROS_LCA(struct TagItem*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 90, DOpus);\
})

#define AddRequesterObject(arg1, arg2) \
    __AddRequesterObject_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#if !defined(NO_INLINE_STDARG) && !defined(DOPUS_NO_INLINE_STDARG)
#define AddRequesterObjectTags(arg1, ...) \
({ \
    const IPTR AddRequesterObject_args[] = { AROS_PP_VARIADIC_CAST2IPTR(__VA_ARGS__) };\
    AddRequesterObject((arg1), (struct TagItem*)(AddRequesterObject_args)); \
})
#endif /* !NO_INLINE_STDARG */

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __RefreshRequesterObject_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, RefreshRequesterObject,\
         AROS_LCA(struct RequesterBase*, (__arg1), A0), \
         AROS_LCA(struct RequesterObject*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 91, DOpus);\
})

#define RefreshRequesterObject(arg1, arg2) \
    __RefreshRequesterObject_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __ObjectText_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC7NR(void, ObjectText,\
         AROS_LCA(struct RequesterBase*, (__arg1), A0), \
         AROS_LCA(short, (__arg2), D0), \
         AROS_LCA(short, (__arg3), D1), \
         AROS_LCA(short, (__arg4), D2), \
         AROS_LCA(short, (__arg5), D3), \
         AROS_LCA(char*, (__arg6), A1), \
         AROS_LCA(short, (__arg7), D4), \
        struct DOpusBase *, (__DOpusBase), 92, DOpus);\
})

#define ObjectText(arg1, arg2, arg3, arg4, arg5, arg6, arg7) \
    __ObjectText_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __DoGlassImage_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC5NR(void, DoGlassImage,\
         AROS_LCA(struct RastPort*, (__arg1), A0), \
         AROS_LCA(struct Gadget*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
         AROS_LCA(int, (__arg5), D2), \
        struct DOpusBase *, (__DOpusBase), 93, DOpus);\
})

#define DoGlassImage(arg1, arg2, arg3, arg4, arg5) \
    __DoGlassImage_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __Decode_RLE_WB(__DOpusBase, __arg1, __arg2, __arg3) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC3NR(void, Decode_RLE,\
         AROS_LCA(char*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
        struct DOpusBase *, (__DOpusBase), 94, DOpus);\
})

#define Decode_RLE(arg1, arg2, arg3) \
    __Decode_RLE_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __ReadStringFile_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, ReadStringFile,\
         AROS_LCA(struct StringData*, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 95, DOpus);\
})

#define ReadStringFile(arg1, arg2) \
    __ReadStringFile_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __FreeStringFile_WB(__DOpusBase, __arg1) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC1NR(void, FreeStringFile,\
         AROS_LCA(struct StringData*, (__arg1), A0), \
        struct DOpusBase *, (__DOpusBase), 96, DOpus);\
})

#define FreeStringFile(arg1) \
    __FreeStringFile_WB(__DOPUS_LIBBASE, (arg1))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __LFreeRemEntry_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, LFreeRemEntry,\
         AROS_LCA(struct DOpusRemember**, (__arg1), A0), \
         AROS_LCA(char*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 97, DOpus);\
})

#define LFreeRemEntry(arg1, arg2) \
    __LFreeRemEntry_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __AddGadgetBorders_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC5NR(void, AddGadgetBorders,\
         AROS_LCA(struct DOpusRemember**, (__arg1), A0), \
         AROS_LCA(struct Gadget*, (__arg2), A1), \
         AROS_LCA(int, (__arg3), D0), \
         AROS_LCA(int, (__arg4), D1), \
         AROS_LCA(int, (__arg5), D2), \
        struct DOpusBase *, (__DOpusBase), 98, DOpus);\
})

#define AddGadgetBorders(arg1, arg2, arg3, arg4, arg5) \
    __AddGadgetBorders_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __CreateGadgetBorders_WB(__DOpusBase, __arg1, __arg2, __arg3, __arg4, __arg5, __arg6, __arg7, __arg8) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC8NR(void, CreateGadgetBorders,\
         AROS_LCA(struct DOpusRemember**, (__arg1), A0), \
         AROS_LCA(int, (__arg2), D0), \
         AROS_LCA(int, (__arg3), D1), \
         AROS_LCA(struct Border**, (__arg4), A1), \
         AROS_LCA(struct Border**, (__arg5), A2), \
         AROS_LCA(int, (__arg6), D2), \
         AROS_LCA(int, (__arg7), D3), \
         AROS_LCA(int, (__arg8), D4), \
        struct DOpusBase *, (__DOpusBase), 99, DOpus);\
})

#define CreateGadgetBorders(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) \
    __CreateGadgetBorders_WB(__DOPUS_LIBBASE, (arg1), (arg2), (arg3), (arg4), (arg5), (arg6), (arg7), (arg8))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __SelectGadget_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2NR(void, SelectGadget,\
         AROS_LCA(struct Window*, (__arg1), A0), \
         AROS_LCA(struct Gadget*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 100, DOpus);\
})

#define SelectGadget(arg1, arg2) \
    __SelectGadget_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

#if !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__)

#define __FSSetMenuStrip_WB(__DOpusBase, __arg1, __arg2) ({\
        AROS_LIBREQ(DOpusBase,22)\
        AROS_LC2(int, FSSetMenuStrip,\
         AROS_LCA(struct Window*, (__arg1), A0), \
         AROS_LCA(struct Menu*, (__arg2), A1), \
        struct DOpusBase *, (__DOpusBase), 101, DOpus);\
})

#define FSSetMenuStrip(arg1, arg2) \
    __FSSetMenuStrip_WB(__DOPUS_LIBBASE, (arg1), (arg2))

#endif /* !defined(__DOPUS_LIBAPI__) || (22 <= __DOPUS_LIBAPI__) */

__END_DECLS

#endif /* DEFINES_DOPUS_H*/
